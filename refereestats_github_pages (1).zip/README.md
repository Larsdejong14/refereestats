# RefereeStats — GitHub Pages

Deze eerste statische versie is geschikt voor GitHub Pages en bevat geen server of API-sleutel.

## Publiceren
1. Open je repository `refereestats` op GitHub.
2. Kies **Add file → Upload files**.
3. Upload `index.html` uit deze map (dus niet het ZIP-bestand zelf).
4. Klik **Commit changes**.
5. Ga naar **Settings → Pages**.
6. Bij **Build and deployment**, kies **Deploy from a branch**.
7. Kies branch `main`, map `/ (root)` en klik **Save**.
8. Wacht een paar minuten. GitHub toont op die pagina je website-link.

## Belangrijke beperking
Deze eerste versie linkt naar de officiële KNVB-aanstellingen. Een statische browserpagina kan de KNVB-pagina niet zomaar automatisch uitlezen door browserbeveiliging en mogelijke wijzigingen aan de bronwebsite. Daarom worden er geen wedstrijd- of scheidsrechtersgegevens verzonnen. Automatische gegevensimport vraagt om een betrouwbare officiële feed/API of een zorgvuldig geteste server-side automatisering.
